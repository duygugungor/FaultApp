﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-VBZJkP5Ujax2xBUGmGSnKwg6YV5s6ca+VVta7GPGG\/Y=",
      "url": "_content\/Radzen.Blazor\/css\/dark-base.css"
    },
    {
      "hash": "sha256-xxvHeTv2qwzPBXHMr+FTpTtWC7UVCO1ElgMhfsQ5TZU=",
      "url": "_content\/Radzen.Blazor\/css\/dark.css"
    },
    {
      "hash": "sha256-hF\/674vYoDUjlYqFpgmE+yXgV5u3CDfqWSchGr\/qhro=",
      "url": "_content\/Radzen.Blazor\/css\/default-base.css"
    },
    {
      "hash": "sha256-gPPvPQCGt6iXwI0DOxdQzJipNQIQj57+S8kAgng+aWc=",
      "url": "_content\/Radzen.Blazor\/css\/default.css"
    },
    {
      "hash": "sha256-a4XM3j\/5dHxtU5wrdZu+7cBwdLPWXEuJmu+7PUvotLU=",
      "url": "_content\/Radzen.Blazor\/css\/humanistic-base.css"
    },
    {
      "hash": "sha256-O7iZ3EKgdLhCVPJRwnKJYJ\/+\/YmbhBUl3V0T8iddF4M=",
      "url": "_content\/Radzen.Blazor\/css\/humanistic.css"
    },
    {
      "hash": "sha256-EEwyn\/QkWCLnQg69NjdguiktLRMfekcbUO+jcm2l0PY=",
      "url": "_content\/Radzen.Blazor\/css\/material-dark.css"
    },
    {
      "hash": "sha256-sBftmfwF68+JMn8kYBcmXn2gYeLwH++Wlre2hKo59vA=",
      "url": "_content\/Radzen.Blazor\/css\/material.css"
    },
    {
      "hash": "sha256-uXtVyUPM2WSfa8SVZQh2nGmugDt9f03CKC0EkeNjaIE=",
      "url": "_content\/Radzen.Blazor\/css\/software-base.css"
    },
    {
      "hash": "sha256-7TpdV9x3TKUjx6NVUTJxoUtxk6G\/t\/wkrwwDIufKwVQ=",
      "url": "_content\/Radzen.Blazor\/css\/software.css"
    },
    {
      "hash": "sha256-hAVusb3T2Wsgi4giZ4DbFaX7kQcCD3ZRwY1CWj2KcD4=",
      "url": "_content\/Radzen.Blazor\/fonts\/MaterialIcons-Regular.woff"
    },
    {
      "hash": "sha256-aY5euu4b9B4uoPbO6pUg0M02KHH1iFkV\/DX7TpV\/l+g=",
      "url": "_content\/Radzen.Blazor\/fonts\/roboto-v15-latin-300.woff"
    },
    {
      "hash": "sha256-PrZc6Ar6Orw126gGmRpfnzIY2LU8S+T5wSSNnZ88Guo=",
      "url": "_content\/Radzen.Blazor\/fonts\/roboto-v15-latin-700.woff"
    },
    {
      "hash": "sha256-l7uYY0Ka6X\/MDNbIDTDD90VNCyGNR1jiTDC9pEG9OdM=",
      "url": "_content\/Radzen.Blazor\/fonts\/roboto-v15-latin-regular.woff"
    },
    {
      "hash": "sha256-4tJ2y83Opy9zhl\/cqC+2kN6Dyj9o+FR2zLmn9aSPwcg=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-Black.woff"
    },
    {
      "hash": "sha256-Se1Ckp\/WChi38Ylv0M9zeWV40BrNdzJZCuL5vLArVss=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-BlackIt.woff"
    },
    {
      "hash": "sha256-iwPDiY3GwHRvR7nxbjO1MUzZ4OIDrBnBE7JVh8uvL7Q=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-Bold.woff"
    },
    {
      "hash": "sha256-hbpdyuMzEkbBLV46tNBW8O4fcBC1OHCZu73IKA\/wxFY=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-BoldIt.woff"
    },
    {
      "hash": "sha256-PLpVAO2hf3ujhcFgIgpvr95XZj15sDT5TlPjBcIKjOo=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-ExtraLight.woff"
    },
    {
      "hash": "sha256-gyjJCK9yyzeB56egUKX2oyJUAHzhrxPnuT+JB1brUjg=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-ExtraLightIt.woff"
    },
    {
      "hash": "sha256-Yi16KO1MmnQJMcyA7nBl9RenDCtzOoi9TIYcCTDYYA0=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-It.woff"
    },
    {
      "hash": "sha256-U\/c5uZXyrUZYibduYAqP66xUX7hjF+MuGqjty6kp+n8=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-Light.woff"
    },
    {
      "hash": "sha256-Wz06DrCrEo8PhVFosBvtv0BwVRad1e6cHVYPrOXcTTk=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-LightIt.woff"
    },
    {
      "hash": "sha256-FUVkwg6zvTHIIS9plEgvWa39AFMb6VCbD1LTENYjsm4=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-Regular.woff"
    },
    {
      "hash": "sha256-0yvxUfB8+6PXLdQAnlit3rprdUByfZdrdEJe4i5AjqY=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-Semibold.woff"
    },
    {
      "hash": "sha256-f7Kf\/RI21ULz4ITMVN+kUuGhpYP3UWYywC73o3WtAgw=",
      "url": "_content\/Radzen.Blazor\/fonts\/SourceSansPro-SemiboldIt.woff"
    },
    {
      "hash": "sha256-ZCobGcyxo83Z8yi1UBt7hke9qFjfMP+hATEquuxmJaU=",
      "url": "_content\/Radzen.Blazor\/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-1DzCJ+2eiXT\/M9r7UtfJnRHxSrsuc29tr+HLj0fel+E=",
      "url": "_content\/Blazorise\/blazorise.css"
    },
    {
      "hash": "sha256-9uyf23uV6Ng0OK8XzXs8aDMed6uH8u\/AYo5BUZ7J7Fk=",
      "url": "_content\/Blazorise\/blazorise.js"
    },
    {
      "hash": "sha256-Not8AR3Vla6jp+noBOy\/ZHV6SUMCMh52O4mx\/ExKHmo=",
      "url": "_content\/Blazorise.Sidebar\/blazorise.sidebar.css"
    },
    {
      "hash": "sha256-8fNRQg6rpoSeaEwD9H\/xHU8OBTlEM880A8eD20escVk=",
      "url": "_content\/Blazorise.Bootstrap\/blazorise.bootstrap.css"
    },
    {
      "hash": "sha256-VhNwMWRD5r3vrVRnyTdJz6BZQfrzaWJOJgh7HUWoSF0=",
      "url": "_content\/Blazorise.Bootstrap\/blazorise.bootstrap.js"
    },
    {
      "hash": "sha256-BHNhq10T\/9aejlrFEhS\/NYeYS3Djwv\/pqg2xUjQCx\/s=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-LjhDZi67VpCgC\/TZWvjkGEfAzw1+74\/MbXPnmEh0AUQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-QQJ9JjzZGj22R3r\/JwEWeFy6eFRmGXZo830JEBrQmGg=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-Q0\/w3R6sGs96poPpeo2iAwSpY8oUl4AFuCIasHJIxtU=",
      "url": "css\/bootstrap-grid.css"
    },
    {
      "hash": "sha256-ypXCAeeMuBj3guj+JhtYVLcKDB1KDgd+omNIEUwltSQ=",
      "url": "css\/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-LEWl65foq4ITGHfcSSKEx1P\/2A37Fdlzek\/ROtocM1E=",
      "url": "css\/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-iVwl9LO8AdkaJ5iFx7N20k1xPQyb9QnZrhCXabKSd6A=",
      "url": "css\/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-cucqCMteWbhkPIw8LpjYc9u\/G7GJW1xG4P3TYNMe2Wk=",
      "url": "css\/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-ZX8UnQmxYrVFF9yClNnxwxvbSIdtBoKobXyxmBGupxM=",
      "url": "css\/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-RAZFytNIDt6qBZ8OvqIF+m7FmDL1qCkUFpeg+fKE05w=",
      "url": "css\/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-E\/ViqaveKxuQ+EERRCLYw0wu\/JZHUkJlOB+9nXunSOU=",
      "url": "css\/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-U4\/KO1UcznrxXkhqDvWEvIdZm2bvRM2vwFsL69iouII=",
      "url": "css\/bootstrap.css"
    },
    {
      "hash": "sha256-2Kf460KofQSIWo467B2JfdhliPmT\/01lM61omexdEG8=",
      "url": "css\/bootstrap.css.map"
    },
    {
      "hash": "sha256-Ww++W3rXBfapN8SZitAvc9jw2Xb+Ixt0rvDsmWmQyTo=",
      "url": "css\/bootstrap.min.css"
    },
    {
      "hash": "sha256-2c79EmAJsUiXtTXODh7+DeQ7\/AIvcdsu+yDftxtNiGY=",
      "url": "css\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-cCOAekwcBGOynfog4vjE2lMg3V30WOLw\/wBKC0F+8l4=",
      "url": "js\/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-DGr+7vxHqH0kNN4naj6zRtwU2Hp3LsXvToxouhCkQU8=",
      "url": "js\/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-9nt4LsWmLI\/O24lTW89IzAKuBqEZ47l\/4rh1+tH\/NY8=",
      "url": "js\/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-R7YPCJVrZvXYlKCDju5OZrJnY63lWn2p8OxznliT020=",
      "url": "js\/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-3ZSqn6+tSt3WzvtJgJuXUhMtXp\/ir6EWgFRAxzPrwi8=",
      "url": "js\/bootstrap.js"
    },
    {
      "hash": "sha256-DUkPybXc3\/BleNVGmjuQM+YnwkSQmwCQfrgIlwhCVbU=",
      "url": "js\/bootstrap.js.map"
    },
    {
      "hash": "sha256-ecWZ3XYM7AwWIaGvSdmipJ2l1F4bN9RXW6zgpeAiZYI=",
      "url": "js\/bootstrap.min.js"
    },
    {
      "hash": "sha256-F6WuQKtSr3O5GZahuRFyFTaDKd50HlukfK16LSZrt6A=",
      "url": "js\/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-btwAf2ttqHm3RvunZ+Fm8L3pi4SDSY6qEreG5DIlzn0=",
      "url": "_framework\/_bin\/BlazorApp4.Client.dll"
    },
    {
      "hash": "sha256-HQeN+ZfHAERO+uW0fP0J9J3WV1hQ3vUIOWbqGSYBPp8=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-kL\/omZDwqByAi+lPdMeDmr3XjHcn4RVb+LmZ4mut1Yc=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-BaZPMj95+YNe3G4ckTGD6szZFwZeA2MOHn91zTGKDeU=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-ZxXy75PYbzJxNfAc\/SAP1nUYm4gt1jSaOpFnBb9m85M=",
      "url": "_framework\/_bin\/System.Buffers.dll"
    },
    {
      "hash": "sha256-EcDo\/GQZkQrOT1Xd0jMPE3NwT5lsMq5DNsPxHVidLDQ=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-\/zcPVM75OAY+joGVM8yIC1gO1SFYWP1CFERgQ8PJkfA=",
      "url": "_framework\/_bin\/netstandard.dll"
    },
    {
      "hash": "sha256-IPbQMdJxZXdk8HTlaPyXdQ6Zb82iZLphnM74yO4EURQ=",
      "url": "_framework\/_bin\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-Zw2\/5aDWjgMedporhjigwhi\/UCLcfl0tfa0LXUyD9HE=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-r6QdEXq0KfB8oZDzhnV4xskSbzJA0yBVi6XFpa3TGHM=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-ob5gN\/szfb1CwWnyQWvWvuid3u4df593KvZeoJQEaKc=",
      "url": "_framework\/_bin\/WebAssembly.Net.WebSockets.dll"
    },
    {
      "hash": "sha256-\/cPXlNTX8GKF\/lIn\/2DIjtxTe0Wpy4ZDcyAj67b6JYk=",
      "url": "_framework\/_bin\/System.Memory.dll"
    },
    {
      "hash": "sha256-6XMT1eT3svGdg6hFzAHJscYdTQjakoYccYTdHmKSr7Y=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-8g0neeYVmPrxWgbMI0ZTVO6257qMisUTPZ78egAnIMw=",
      "url": "_framework\/_bin\/System.Numerics.dll"
    },
    {
      "hash": "sha256-RMOYBniHZkD8OZrBV3ONIMTZqsBhSAcBFm4pVuY9dv4=",
      "url": "_framework\/_bin\/System.Xml.dll"
    },
    {
      "hash": "sha256-fMngt4py0YmfHqV6eONyCI6R5m+YOE7KZ3U4MzCrskE=",
      "url": "_framework\/_bin\/Mono.Security.dll"
    },
    {
      "hash": "sha256-VAHA4LWcsdHUBgFG1\/xwhc4IyJ0ZH9UyK9+qSPzDa6Y=",
      "url": "_framework\/_bin\/System.Transactions.dll"
    },
    {
      "hash": "sha256-C09aqx1vDLK7zQ9XnZcUqAgTDRwybxhRg\/FR8HSk1v8=",
      "url": "_framework\/_bin\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-6mtLxbGMMGcIfch8cp0W9gmBoI493AxBRUPGEzOn3nU=",
      "url": "_framework\/_bin\/System.ServiceModel.Internals.dll"
    },
    {
      "hash": "sha256-moW4EYN6ExD6T0vSBMMggn62cZaTd8dSr9b\/yj\/9dPM=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-LUtkiqNd5ABTiuiYaqzaJxVjPq+Z4FqezuIWk\/faqSA=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-R8CUbbWAKar388eFQJhUgiTgLEv2Mih9wr9iO0P7ImU=",
      "url": "_framework\/_bin\/System.ComponentModel.Composition.dll"
    },
    {
      "hash": "sha256-ptCMHBy9q8MMLU0ukLMuvvhQk\/yYljw37MTKtfsvuFQ=",
      "url": "_framework\/_bin\/System.IO.Compression.FileSystem.dll"
    },
    {
      "hash": "sha256-hLbkXBzxUk9DSXYTLGRowe+80rxmpXsqEZbPIL4+5zs=",
      "url": "_framework\/_bin\/System.IO.Compression.dll"
    },
    {
      "hash": "sha256-vcCLMX4xAsUqKuQjjIkzu1O9pHGO\/tdvysgSmEjL6oo=",
      "url": "_framework\/_bin\/System.Drawing.Common.dll"
    },
    {
      "hash": "sha256-eejp4oI3sQBq\/tI6GsJNaPu3Dkdot5Vbn8+R3w2vYLE=",
      "url": "_framework\/_bin\/System.Data.DataSetExtensions.dll"
    },
    {
      "hash": "sha256-dxfTuT6ffPMmvuUUTfv7+bpLtOZZZHQdz77hjhy9qHw=",
      "url": "_framework\/_bin\/System.Data.dll"
    },
    {
      "hash": "sha256-TkH6yxFQlTfY8NfznePrCdYJiEVpM9Dqy4Uu4H9qk10=",
      "url": "_framework\/_bin\/System.Threading.Tasks.Extensions.dll"
    },
    {
      "hash": "sha256-qAKfFnquY+7UC\/MzLi04rjqEhLzTryCoLg\/S6MxI19I=",
      "url": "_framework\/_bin\/System.Numerics.Vectors.dll"
    },
    {
      "hash": "sha256-Tqh1Da+iTRQJEZUGAsMNFuZ4hf1PMf13WApRZod+uw4=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-WkuXkEV\/\/B1J2kYqjuSPxgHubOHALmA548PhKTed2JE=",
      "url": "_framework\/_bin\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-RcGmVD6GepoLNUlt0DdL7ME67TycUDtJcWzHJwBUtIA=",
      "url": "_framework\/_bin\/Blazorise.Icons.FontAwesome.dll"
    },
    {
      "hash": "sha256-PEg9ghiKSWBTX0jq8pFDvv2Yvw92Y8W0ELtWrSE4fhA=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-82ZFUNQ\/lINILPY15Gjhju9hI7B2BXjHEQQDTeXhVek=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-tjbh51aVu1kTNULze+ql74GraZd0WcTaq28VNttAPKA=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-hbUQCCeR7kLtkXTi7cA3LzwJA0OgAL\/+vZwKdJYa17Y=",
      "url": "_framework\/_bin\/Blazorise.dll"
    },
    {
      "hash": "sha256-tmnkCmP9OzLUkpQ3LP7PRosi7gt5pyfEZCM6aqAokFI=",
      "url": "_framework\/_bin\/System.ComponentModel.Annotations.dll"
    },
    {
      "hash": "sha256-LIfCYwg+PHltTK4z3EnbSkA7m2cn8JS4jHVthdKrDF8=",
      "url": "_framework\/_bin\/System.ComponentModel.DataAnnotations.dll"
    },
    {
      "hash": "sha256-m7Q+cF5\/ji3OMfdGlCuE8pQ\/iM+kxNHLq\/IEWVvIaOg=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Forms.dll"
    },
    {
      "hash": "sha256-bSgsT2x5xMvs8mara5wU+EJwcyHa9GVMU85HwhWcdWM=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-LqwA2Rpm96Ualk0IhLZar87kfRCyKHzHTeTt2jYhm7M=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-okC5XVUVhglJYarRu8Qkia35ZRSTrER64Vz2gR3+yCA=",
      "url": "_framework\/_bin\/Blazorise.Bootstrap.dll"
    },
    {
      "hash": "sha256-2quVwn0qYIpeYL5QJwoS4zClxfiYPKyaiN9iw\/uk5ZI=",
      "url": "_framework\/_bin\/Radzen.Blazor.dll"
    },
    {
      "hash": "sha256-ubyINHXDmWOAugBDEb8CCz+uV68eordXiYDxpUeRBvg=",
      "url": "_framework\/_bin\/Microsoft.CSharp.dll"
    },
    {
      "hash": "sha256-aHqvd\/TLf\/ZZOpXlafzNNthD2HjPJLadm9zDFZWm39k=",
      "url": "_framework\/_bin\/System.Linq.Dynamic.Core.dll"
    },
    {
      "hash": "sha256-yTznKFXYjwtGYUGUdxYEw8gA1A+IWlMYOncOmAAyJas=",
      "url": "_framework\/_bin\/System.Reflection.Emit.ILGeneration.dll"
    },
    {
      "hash": "sha256-4A297N6Xf0UZNMTrY+4COe43Hmcrtxb\/eTiqTJ5M6wA=",
      "url": "_framework\/_bin\/System.Reflection.Emit.dll"
    },
    {
      "hash": "sha256-kUVmMFnYGvdvJBJNHHb0cfFBjxcJyeJhKCoPddIW6rg=",
      "url": "_framework\/_bin\/BlazorApp4.Shared.dll"
    },
    {
      "hash": "sha256-2mH6sSaylXDwlnPhEFv1muVGZaZbdQnXYpW1MzQXIOc=",
      "url": "_framework\/_bin\/Blazorise.Sidebar.dll"
    },
    {
      "hash": "sha256-FJ+rEgcx6ljTxwbRXZSUGfrDKpVvOxHCSfNxbnXNn3M=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-woXzLY7bKAonfaX3WRGOcU27gyvyyzyQmcAipiTAcNQ=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-ylX7VKoH7433xA+yHLYr6lPOuhCKV4qhw7GLUx6J82E=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-Pv0bA+gEl+gycgBRmD7++LIzBA66qcH+b7G5FecHyVY=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-1T9tyZDZIAxKTpjY0la\/wOldY8VPnH6edD95RC80r2E=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-mQqyOIjuVduaLQ7ZyvDrChDLp8rTeQknIIWDzqsO4eY=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-3trD3kyUrc0a2IrNSfLT2rSZ35MMdD2qtqG+vk+U8QA=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.FileExtensions.dll"
    },
    {
      "hash": "sha256-tY1dlliVr+yGzBF7d0z\/iaulZfBJNaSrCKDD0RP2cc8=",
      "url": "_framework\/_bin\/Microsoft.Extensions.FileProviders.Physical.dll"
    },
    {
      "hash": "sha256-r8LuqDQgcB\/c3E48xHqsAY1eRZB1ZtuqZF6nlufn7kg=",
      "url": "_framework\/_bin\/Microsoft.Extensions.FileSystemGlobbing.dll"
    },
    {
      "hash": "sha256-DrtNiKIMjfSOdamH5Bs5zHmjFADgNiwrY5tRgTm6XuI=",
      "url": "_framework\/_bin\/Microsoft.Extensions.FileProviders.Abstractions.dll"
    },
    {
      "hash": "sha256-gvKHi9toHG8QIQVxMYdBMoUZdhhpivawq\/rZEmTaSkI=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-CNukDMTMsZ77nI593UgjfZkJqNhgDLvnpUjL2QzFL2M=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-czNf3btAeBW\/vvID5LAfgcsNZ+GM3ssVuPaMflcg0rs=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-Fr9pmmHkDatKCKAWZvfCiEu0dDRe57TIepE19RZA6fE=",
      "url": "_framework\/_bin\/BlazorApp4.Client.pdb"
    },
    {
      "hash": "sha256-TUdNbGDz+ogqJea4nbn9e5NAJa8g20Wv3as0sLQ8J+o=",
      "url": "_framework\/_bin\/System.Linq.Dynamic.Core.pdb"
    },
    {
      "hash": "sha256-sMBzYA+Oc4u\/Nf+E4reFiyFdto+vNo3R0pLdAaAvTbo=",
      "url": "_framework\/_bin\/BlazorApp4.Shared.pdb"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-\/1W\/\/EN0bvaXMB9VpbLliw1XSYhq6gtirLuyQRtTo7s=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "NbyW9UIR"
};
